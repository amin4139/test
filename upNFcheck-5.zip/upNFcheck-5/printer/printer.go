package printer

import (
	"fmt"

	"github.com/sjlleo/netflix-verify/verify"
)

const (
	AUTHOR        = "@sjlleo"
	VERSION       = "v3.0"
	RED_PREFIX    = "\033[1;31m"
	GREEN_PREFIX  = "\033[1;32m"
	YELLOW_PREFIX = "\033[1;33m"
	BLUE_PREFIX   = "\033[1;34m"
	PURPLE_PREFIX = "\033[1;35m"
	CYAN_PREFIX   = "\033[1;36m"
	RESET_PREFIX  = "\033[0m"
)

func Print(fr verify.FinalResult) {
	printVersion()
	printResult("4", fr.Res[1])
	fmt.Println()
	printResult("6", fr.Res[2])
}

func printVersion() {
	fmt.Println("**NetFlix 解锁检测小工具 " + VERSION + " By " + CYAN_PREFIX + AUTHOR + RESET_PREFIX + "**")
}

func printResult(ipVersion string, vResponse verify.VerifyResponse) {
	fmt.Printf("[IPv%s]\n", ipVersion)
	switch code := vResponse.StatusCode; {
	case code < -1:
		fmt.Println("检测到网络读取有问题，再次进入脚本可能就好了")
		fmt.Println(vResponse.CountryName)
	case code == -1:
		fmt.Println("杯具，当前的IP不提供Netflix服务")
		fmt.Println(vResponse.CountryName)
	case code == 0:
		fmt.Println("当前所在的国家提供Netflix服务，但是您的IP疑似代理，无法正常使用服务")
		fmt.Println(vResponse.CountryName)
	case code == 1:
		fmt.Println("遗憾，仅可观看Netflix自制剧")
		fmt.Println(vResponse.CountryName)
	case code == 2:
		fmt.Println("恭喜，支持观看Netflix非自制剧")
		fmt.Println(vResponse.CountryName)
	case code == 3:
		fmt.Println("出口IP无法观看此电影")
		fmt.Println(vResponse.CountryName)
	case code == 4:
		fmt.Println("出口IP可以观看此电影")
		fmt.Println(vResponse.CountryName)
	default:
		fmt.Println("解锁检测失败，请稍后重试")
		fmt.Println(vResponse.CountryName)
	}
}
